-La cartella "codice" contiene il codice in Flowgorithm:
	-"edipo.fprg", l'esempio di avventura testuale il cui codice verrà consegnato agli studenti
	-"ulisse_e_polifemo", l'esempio di avventura testuale il cui codice non verrà consegnato agli studenti, ma ne vedranno a lezione solo il diagramma di flusso principale

-La cartella "eseguibile" contiene il file "Ulisse.jar". E' il programma generato con flowgorithm da "ulisse_e_polifemo". Questo sarà consegnato agli studenti che potranno prendere spunto eseguendolo da linea di comando.

-La cartella "relazione" contiene il pdf con il resoconto del lavoro